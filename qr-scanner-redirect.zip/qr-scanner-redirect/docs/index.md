# QR Scanner Redirect
Wordpress web qr-scanner with redirect function
