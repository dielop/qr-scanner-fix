<?php
/*
  Plugin Name: QR Scanner Redirect
  Plugin URI: https://github.com/aigenseer/qr-scanner-redirect
  description: Wordpress web qr-scanner with redirect function
  Version: 1.0.4
  Author: Viktor Aigenseer
  Author URI: https://github.com/aigenseer/
*/
include "plugin/index.php";
